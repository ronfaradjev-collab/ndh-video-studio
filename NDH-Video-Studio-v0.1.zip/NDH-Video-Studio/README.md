# NDH Video Studio

Local Hebrew-first real-estate video composer. Read [README_HE.md](README_HE.md) for setup and usage.

Defaults: **he / female / luxury / 60 seconds / captions on / music on / YouTube 1080p**.

Architecture: Streamlit + FFmpeg + Pillow + optional Microsoft Edge neural voice (`edge-tts`) or official Azure Speech F0.

Requirements: Python 3.11–3.12, FFmpeg with libx264 and libass, fonts supporting Hebrew.

Start: `python -m streamlit run app.py` from an installed Python environment.
