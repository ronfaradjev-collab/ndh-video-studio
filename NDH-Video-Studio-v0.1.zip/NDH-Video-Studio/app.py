"""Start with: streamlit run app.py"""
import os
from pathlib import Path
from uuid import uuid4

import streamlit as st
from dotenv import load_dotenv

from ndh_video.config import Branding, VideoConfig
from ndh_video.pipeline import produce
from ndh_video.utils import VideoStudioError

load_dotenv()
ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "output" / "jobs"

st.set_page_config(page_title="NDH Video Studio", page_icon="🎬", layout="wide")
st.markdown("""
<style>
.stApp { background: #101a28; color: #f6f0e4; }
[data-testid="stSidebar"] { background: #162435; }
h1, h2, h3 { letter-spacing: -.02em; }
.stButton button[kind=primary] {background: #b89a70; color: #112032; border: none;}
</style>
""", unsafe_allow_html=True)

st.title("NDH Video Studio")
st.caption("Luxury real-estate film producer  •  Netanya Dream Home  •  Local MVP v0.1")

with st.sidebar:
    st.subheader("הגדרות הפקה")
    st.selectbox("שפה", ["עברית (he)"], disabled=True)
    st.selectbox("קול", ["אישה — Hila Neural"], disabled=True)
    st.selectbox("סגנון", ["Luxury Editorial"], disabled=True)
    length = st.number_input("אורך הסרטון בשניות", min_value=12, max_value=180, value=60, step=5)
    subtitles = st.checkbox("כתוביות מוטמעות + SRT", value=True)
    use_music = st.checkbox("מוזיקת רקע", value=True)
    provider_label = st.selectbox("מקור הקריינות", [
        "Microsoft Edge — חינמי, דורש אינטרנט",
        "Azure Speech F0 — שירות רשמי (מפתח)",
        "העלאת MP3/WAV קיים",
    ])
    provider = "edge" if provider_label.startswith("Microsoft") else "azure" if provider_label.startswith("Azure") else "file"
    preview = st.checkbox("הרצת בדיקת 540p מהירה", value=False)
    st.caption("גרסת ברירת המחדל: YouTube 1920×1080, 25fps, MP4")

left, right = st.columns([1.15, 0.85], gap="large")
with left:
    st.subheader("חומרי הגלם")
    media_uploads = st.file_uploader(
        "בחרו תמונות וסרטוני נכס, בסדר שבו הם צריכים להופיע",
        type=["jpg", "jpeg", "png", "webp", "mp4", "mov", "m4v", "mkv", "webm"],
        accept_multiple_files=True,
    )
    title = st.text_input("כותרת הנכס לפתיח", value="בית יוצא דופן בנתניה")
    script = st.text_area(
        "תסריט הקריינות — יש לאשר את העובדות לפני פרסום",
        value=(
            "ברוכים הבאים לסיור בנכס מיוחד בנתניה. "
            "כאן, בין אור טבעי, מרחבים נעימים ואווירה שקטה, אפשר להתחיל לדמיין את החיים בבית הבא שלכם. "
            "הצטרפו אלינו להתרשמות מהחללים, מהתכנון ומהפרטים שמעניקים לבית את האופי שלו. "
            "אני מרינה, יועצת נדל״ן מבית הום אין ישראל, ואשמח להכיר לכם את הנכס, "
            "להשיב על השאלות החשובות וללוות אתכם לאורך הדרך. "
            "רוצים לדעת עוד או לתאם סיור פרטי? צרו איתי קשר. נתניה דרים הום."
        ),
        height=230,
    )
with right:
    st.subheader("מיתוג ומוזיקה")
    st.caption("להפקה מלאה כדאי להעלות תמונה אמיתית של מרינה ולוגו Home in Israel.")
    portrait = st.file_uploader("תמונת מרינה (אופציונלי)", type=["jpg", "jpeg", "png"])
    logo = st.file_uploader("לוגו שקוף (אופציונלי)", type=["png", "webp"])
    soundtrack = st.file_uploader("מוזיקה ברישיון מתאים (אופציונלי; אחרת תיווצר מוזיקה מקורית)", type=["mp3", "wav", "m4a"])
    supplied_voice = st.file_uploader("קובץ קריינות קיים (למצב העלאה)", type=["mp3", "wav", "m4a"]) if provider == "file" else None
    website = st.text_input("אתר אינטרנט", value="netanyadreamhome.com")
    phone = st.text_input("טלפון", value="+972 54-649-8202")
    if media_uploads:
        st.info(f"נבחרו {len(media_uploads)} קבצים. סדר הבחירה הוא סדר העריכה.")


def store_file(uploaded, folder: Path, index: int) -> Path | None:
    if uploaded is None:
        return None
    extension = Path(uploaded.name).suffix.lower()
    safe = folder / f"upload_{index:03}_{uuid4().hex[:8]}{extension}"
    safe.write_bytes(uploaded.getvalue())
    return safe


if st.button("🎬  Generate Video", type="primary", use_container_width=True):
    if not media_uploads:
        st.error("יש להעלות לפחות תמונה או סרטון אחד.")
    elif provider == "file" and not supplied_voice:
        st.error("נבחר מצב קובץ קריינות. יש להעלות MP3/WAV.")
    else:
        job = OUTPUT / uuid4().hex[:12]
        uploads = job / "uploads"
        uploads.mkdir(parents=True, exist_ok=True)
        try:
            files = [store_file(f, uploads, i) for i, f in enumerate(media_uploads)]
            branding = Branding(
                property_title=title.strip(), website=website.strip(), phone=phone.strip(),
                portrait=store_file(portrait, uploads, 900),
                logo=store_file(logo, uploads, 901),
                soundtrack=store_file(soundtrack, uploads, 902),
            )
            voice_file = store_file(supplied_voice, uploads, 903)
            w, h = (960, 540) if preview else (1920, 1080)
            cfg = VideoConfig(duration=int(length), captions=subtitles, music=use_music,
                              width=w, height=h, voice_provider=provider)
            status = st.empty()
            bar = st.progress(0)

            def on_progress(msg: str, fraction: float) -> None:
                status.write(msg)
                bar.progress(min(100, round(fraction * 100)))

            result = produce(files, script, branding, cfg, job, voice_file, on_progress)
            st.session_state["ndh_last_result"] = {k: str(v) for k, v in result.items() if k != "details"}
            st.success("הסרטון הופק בהצלחה")
            if result["details"]["caption_timing"] != "word_boundaries":
                st.warning("התזמון של הכתוביות מוערך ולא נמדד ברמת מילה. מומלץ לבדוק לפני פרסום.")
        except (VideoStudioError, Exception) as exc:
            st.error(f"ההפקה נכשלה: {exc}")
            st.caption(f"קובצי הביניים נשמרו לעיון בתיקייה: {job}")

result_paths = st.session_state.get("ndh_last_result")
if result_paths:
    video_path = Path(result_paths["video"])
    if video_path.exists():
        st.subheader("הסרטון המוכן")
        st.video(str(video_path))
        st.download_button("הורדת MP4", data=video_path.read_bytes(), file_name=video_path.name, mime="video/mp4")
        srt_path = Path(result_paths["subtitles"])
        st.download_button("הורדת כתוביות SRT", data=srt_path.read_bytes(), file_name="captions.srt", mime="text/plain")
        st.caption(f"כל תוצרי ההפקה שמורים ב: {video_path.parent}")
