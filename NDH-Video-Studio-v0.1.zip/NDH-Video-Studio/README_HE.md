# NDH Video Studio · גרסת MVP 0.1

מערכת מקומית להפקת סרטוני נכסים בסגנון **Luxury Editorial**, עם תמונות וסרטונים, תנועת מצלמה עדינה, קריינות נשית בעברית, כתוביות SRT ומוטמעות, מוזיקה, ופתיח/סיום ממותגים של מרינה / Home in Israel.

**ברירות מחדל:** עברית (`he`), קול נשי `he-IL-HilaNeural`, סגנון `luxury`, אורך `60` שניות, כתוביות ומוזיקה מופעלות, וידאו YouTube 16:9 בגודל `1920×1080` ו־25fps.

## התקנה ראשונית · Windows 11

1. התקן **Python 3.11 או 3.12** מאתר python.org, כולל הסימון **Add python.exe to PATH**.
2. התקן **FFmpeg** עם `ffmpeg` ו־`ffprobe`. אם מותקן winget:

   ```powershell
   winget install --id Gyan.FFmpeg -e
   ```

   פתח Terminal חדש וודא ששתי הפקודות עובדות:

   ```powershell
   ffmpeg -version
   ffprobe -version
   ```

3. חלץ את קובץ ה־ZIP, פתח PowerShell בתיקיית `NDH-Video-Studio` והריץ:

   ```powershell
   py -3.11 -m venv .venv
   .venv\Scripts\python.exe -m pip install --upgrade pip
   .venv\Scripts\python.exe -m pip install -r requirements.txt
   .venv\Scripts\python.exe -m streamlit run app.py
   ```

   אפשר להחליף את `py -3.11` ב־`py -3.12` אם זו הגרסה המותקנת.

4. פתח בדפדפן `http://localhost:8501`. להפעלות הבאות לחץ פעמיים על `run-windows.bat`.

**אם Windows חסם הפעלה של pip / PowerShell:** הפקודות כאן מפעילות את Python ישירות מתוך הסביבה, ללא צורך ב־`Activate.ps1`.

## התקנה · macOS / Linux

דרישות: Python 3.11+, FFmpeg עם `libx264` ו־`libass`, פונט עברי איכותי (מומלץ Noto Sans Hebrew + Noto Serif Hebrew). 

macOS עם Homebrew:

```bash
brew install python@3.11 ffmpeg
python3.11 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
./run-mac-linux.sh
```

Ubuntu/Debian:

```bash
sudo apt update
sudo apt install python3-venv python3-pip ffmpeg fonts-noto-core
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
./run-mac-linux.sh
```

## איך להפיק סרטון

1. העלה תמונות וסרטוני נכס (`JPG/PNG/WEBP`, `MP4/MOV/MKV/WEBM`). הסדר שנבחר הוא סדר הסצנות.
2. הזן **כותרת נכס מדויקת** וטקסט קריינות בעברית. התוכן לדוגמה אינו מתיימר לזהות את הנכס או לתאר עובדות שלא נמסרו.
3. רצוי להעלות תמונת מרינה אמיתית ולוגו Home in Israel בפורמט שקוף. ללא תמונות מיתוג תופיע חלופת טקסט.
4. בחר `Microsoft Edge` (ללא API key). המנוע מנסה להשתמש בקול `he-IL-HilaNeural` ובחותמות זמן ברמת המילה. **נדרש חיבור לאינטרנט**.
5. השאר כתוביות ומוזיקה מופעלות. ניתן להעלות פסקול בעל רישיון שימוש מתאים. ללא קובץ, נוצרת מוזיקת רקע אלקטרונית פשוטה מקורית במחשב (ללא הורדות).
6. לחץ `Generate Video`. אפשר להפעיל תחילה מצב `540p` לבדיקת עיצוב ומהירות.
7. צפה בתוצאה והורד `MP4` ו־`captions.srt`. תוצרי הביניים נשמרים תחת `output/jobs/<job_id>/` כולל דוח JSON.

## קריינות: איכות, אמינות ועלות

- **Edge (`edge-tts`)**: קול Neural איכותי, ללא מפתח API וללא חיוב ישיר; תלוי בשירות אינטרנט לא־רשמי, שעלול להפסיק לעבוד או להשתנות. הוא **אינו SLA עסקי**, ויש לבדוק תנאי שימוש רלוונטיים לפני הפקה מסחרית.
- **Azure Speech F0**: אפשרות רשמית ויציבה יותר בכפוף לרישום, זמינות, תנאי שימוש ומכסה חינמית. נכון לאוקטובר 2026 דף Microsoft מציג **500,000 תווי Neural TTS חינם בחודש** בתוכנית F0. אין הבטחה שמכסה/תנאים לא ישתנו. הגדר מפתח ו־region, ראה בהמשך.
- **קובץ קריינות**: העלאת MP3/WAV/M4A, שימוש גם ללא TTS ברשת; תזמון כתוביות במצב זה הוא **הערכה לפי הטקסט** ואינו מיושר בפועל למילים שהוקלטו.

Azure אופציונלי:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements-azure.txt
copy .env.example .env
```

ערוך `.env` והוסף `AZURE_SPEECH_KEY` ו־`AZURE_SPEECH_REGION` (למשל `westeurope` אם זו ה־region שבה נוצר המשאב). בחר Azure בממשק. אל תעלה `.env` ל־GitHub.

## תכנון טכני

- `app.py` — UI מקומי ב־Streamlit
- `ndh_video/config.py` — תצורת סרטון ונתוני מיתוג
- `ndh_video/tts.py` — Edge / Azure / קובץ מוקלט
- `ndh_video/captions.py` — WordBoundaries, SRT ו־ASS עברית
- `ndh_video/branding.py` — עיצוב פתיח וסיום עם Pillow
- `ndh_video/render.py` — הכנת סצנות וקידוד עם FFmpeg
- `ndh_video/music.py` — פסקול מקורי פשוט שנוצר מקומית
- `ndh_video/pipeline.py` — ניהול המשימה, אימות קבצים, דוח תוצאות
- `tests/` — בדיקות אוטומטיות + בדיקת רינדור אופליין

## בדיקות מקומיות

```powershell
.venv\Scripts\python.exe -m pip install pytest
.venv\Scripts\python.exe -m pytest -q
.venv\Scripts\python.exe tests\smoke_render.py
```

ל־macOS/Linux השתמש בקידומת `.venv/bin/python`.

## מגבלות הגרסה הראשונה

- **אין עדיין הבנה חזותית AI** של חדרים או בחירה אוטונומית בקליפים מוצלחים. המערכת משתמשת בסדר העלאת הקבצים, ובקטעי וידאו מתחילתם. קטעים קצרים עלולים לחזור על עצמם.
- אין עדיין crossfade, זיהוי מוזיקה לפי סצנה, ניתוח איכות צילום, הסרת רעשי רקע או בימוי קולנועי אוטומטי. זוהי תשתית עבודה עם תנועת תמונות, חיתוכים, קריינות, מיתוג והפקה.
- הקול והמוזיקה תלויים במקור/איכות הקבצים ובזכויות לשימוש מסחרי.
- סרטוני 1080p על מחשב חלש עלולים להימשך זמן רב ולצרוך CPU/מקום בדיסק; 540p מיועד לתצוגה מקדימה בלבד.
- WordBoundary תלוי בתמיכת ספק הקריינות. אם חסר, הכתוביות יתוזמנו בהערכה ויופיע סימון בדוח ההפקה.
- אין פרסום אוטומטי ל־YouTube בשלב זה; מופק קובץ מותאם להעלאה ידנית.
- שימוש בפונט דורש פונט עם תמיכה בעברית במחשב. אין גופנים הכלולים בארכיון.
- המשתמש נדרש לבדוק עובדות על הנכס, מיתוג, טלפונים, זכויות תמונות, מוזיקה וקול לפני העלאה לפלטפורמה ציבורית.

## שלב פיתוח הבא

1. תסריט אוטומטי לפי פרטי נכס מאומתים, עם פיקוח אנושי.
2. ניתוח חזותי מקומי לבחירת תמונות ושוטים לפי חדרים ואיכות.
3. מערכת סצנות עשירה: crossfade, תנועות מצלמה משתנות, Lower Third והצגת פרטי נכס תוך כדי וידאו.
4. שיפור מוזיקה ורמות שמע, צלילי מעבר ומוזיקה ברישיון ברור.
5. טמפלטים ל־9:16, מעבר לארבע שפות ואופטימיזציה למדיה חברתית.

## פתרון תקלות

- `ffmpeg missing from PATH` — הוסף את FFmpeg ל־PATH והפעל Terminal חדש.
- `FFmpeg must be compiled with libass` — התקן חבילת FFmpeg מלאה שתומכת בכתוביות.
- `Edge speech service failed` — בדוק רשת; אם התקלה חזרה, בחר Azure F0 או קריינות שהוקלטה מראש.
- `Voice lasts ... available slot ...` — קצר את התסריט או הארך את הסרטון מעבר ל־60 שניות.
- אם העברית מוצגת הפוך או בפונט לא מתאים, התקן Noto Sans Hebrew והגדר `NDH_FONT_SANS` ו־`NDH_FONT_SERIF` בקובץ `.env` לנתיבי גופנים מותקנים.

---

פיתוח עצמאי עבור Netanya Dream Home. התוכנה החופשית אינה מחייבת תשלום, אבל אינטרנט, מחשב והוצאות נוספות כגון חשבון Azure מחוץ למכסה החינמית אינם כלולים ב־"0 ₪".
