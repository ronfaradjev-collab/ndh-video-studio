"""Offline end-to-end test: python tests/smoke_render.py"""
import math
import sys
import tempfile
import wave
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ndh_video.config import Branding, VideoConfig
from ndh_video.pipeline import produce
from ndh_video.utils import duration, probe


def main():
    root = Path(tempfile.mkdtemp(prefix="ndh-smoke-"))
    img = root / "photo.jpg"
    picture = Image.new("RGB", (720, 400), (66, 92, 108))
    d = ImageDraw.Draw(picture)
    d.rectangle((80, 140, 640, 360), fill=(220, 206, 183))
    picture.save(img)
    voice = root / "voice.wav"
    sr = 22050
    t = np.arange(2 * sr) / sr
    y = np.int16(np.sin(t * 2 * math.pi * 210) * 1000)
    with wave.open(str(voice), "wb") as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(sr); f.writeframes(y.tobytes())
    result = produce(
        media=[img], script="שלום וברוכים הבאים לבית מיוחד בנתניה",
        branding=Branding(property_title="וילה מיוחדת בנתניה"),
        cfg=VideoConfig(duration=13, width=320, height=180, voice_provider="file"),
        job=root / "job", voice_file=voice,
    )
    video = result["video"]
    assert video.stat().st_size > 10000
    length = duration(video)
    assert abs(length - 13) < .14, length
    assert any(s["codec_type"] == "audio" for s in probe(video)["streams"])
    assert "שלום" in result["subtitles"].read_text(encoding="utf-8-sig")
    print(f"PASS: {video} ({length:.2f}s / {video.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
