from pathlib import Path

from ndh_video.captions import make_cues, write_subtitles
from ndh_video.config import VideoConfig
from ndh_video.render import segment_plan
from ndh_video.tts import Word


def test_defaults_and_total():
    cfg = VideoConfig()
    cfg.validate()
    assert cfg.duration == 60 and cfg.main_seconds == 52
    assert cfg.voice_max_seconds > 50


def test_segment_plan_exact_seconds():
    a = [Path("a.jpg"), Path("b.mp4")]
    plan = segment_plan(a, 52)
    assert abs(sum(t for _, t in plan) - 52) < .00001
    assert len(plan) >= 8
    assert set(path for path, _ in plan) == set(a)


def test_hebrew_captions(tmp_path):
    words = [Word(0.2 * i, .2 * (i + 1), w) for i, w in enumerate("ברוכים הבאים לסיור בנכס יפה בנתניה".split())]
    cues, exact = make_cues(words, "", 3, 4)
    assert exact and cues[0].start == 4
    assert cues[0].text.startswith("ברוכים")
    write_subtitles(cues, tmp_path, 1080)
    srt = (tmp_path / "captions.srt").read_text(encoding="utf-8-sig")
    assert "00:00:04,000" in srt and "ברוכים" in srt
    assert "Dialogue: 0" in (tmp_path / "captions.ass").read_text(encoding="utf-8")


def test_estimated_captions():
    cues, exact = make_cues([], "שלום עולם", 2, 4)
    assert not exact and len(cues) == 1
    assert cues[0].end <= 6.2
