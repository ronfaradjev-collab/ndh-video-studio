"""Export YouTube SRT and embedded-caption ASS without machine transcription."""
import re
from dataclasses import dataclass
from pathlib import Path

from .tts import Word


@dataclass
class Cue:
    start: float
    end: float
    text: str


def make_cues(words: list[Word], script: str, audio_seconds: float, offset: float = 0) -> tuple[list[Cue], bool]:
    """True means derived from word boundaries, False means estimated from the script."""
    exact = bool(words)
    if not words:
        tokens = re.findall(r"\S+", script)
        if not tokens:
            return [], False
        per = audio_seconds / len(tokens)
        words = [Word(i * per, (i + 1) * per, token) for i, token in enumerate(tokens)]
    words = sorted((w for w in words if w.text.strip()), key=lambda w: w.start)
    cues: list[Cue] = []
    for i in range(0, len(words), 5):
        piece = words[i:i + 5]
        if not piece:
            continue
        start = max(0, piece[0].start + offset)
        end = min(audio_seconds + offset, max(start + 0.28, piece[-1].end + offset + 0.12))
        # Longer gaps should not leave the last caption hanging.
        if i + 5 < len(words):
            end = min(end, words[i + 5].start + offset - 0.02)
        end = max(start + 0.16, end)
        cues.append(Cue(start, end, " ".join(w.text for w in piece)))
    return cues, exact


def srt_time(secs: float) -> str:
    millis = max(0, round(secs * 1000))
    h, remainder = divmod(millis, 3600_000)
    m, remainder = divmod(remainder, 60_000)
    s, ms = divmod(remainder, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"


def ass_time(secs: float) -> str:
    centis = max(0, round(secs * 100))
    h, remainder = divmod(centis, 360_000)
    m, remainder = divmod(remainder, 6_000)
    s, cs = divmod(remainder, 100)
    return f"{h}:{m:02}:{s:02}.{cs:02}"


def write_subtitles(cues: list[Cue], out_dir: Path, height: int) -> None:
    srt = out_dir / "captions.srt"
    srt.write_text("\n\n".join(
        f"{i}\n{srt_time(c.start)} --> {srt_time(c.end)}\n{c.text}"
        for i, c in enumerate(cues, 1)
    ) + "\n", encoding="utf-8-sig")

    # Libass handles BiDi and shaping; substitute font to suit the host OS.
    import platform
    family = "Arial" if platform.system() == "Windows" else "Noto Sans Hebrew" if platform.system() == "Linux" else "Arial"
    fontsize = max(20, round(height * 0.047))
    margin = round(height * 0.067)
    header = f"""[Script Info]
Title: NDH Video Studio subtitles
ScriptType: v4.00+
PlayResX: 1920
PlayResY: {height}
ScaledBorderAndShadow: yes
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Luxury,{family},{fontsize},&H00FFFFFF,&H00FFFFFF,&HAF061323,&H70000000,-1,0,0,0,100,100,0,0,1,3,1,2,40,40,{margin},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
""".replace("PlayResX: 1920", f"PlayResX: {round(height * 16 / 9)}")
    # UTF-8 Hebrew, no embedded dynamic ASS tags from user content.
    rows = [header]
    for c in cues:
        safe = re.sub(r"[{}]", "", c.text).replace("\\", "").replace("\n", " ")
        rows.append(f"Dialogue: 0,{ass_time(c.start)},{ass_time(c.end)},Luxury,,0,0,0,,\u200f{safe}\n")
    (out_dir / "captions.ass").write_text("".join(rows), encoding="utf-8")
