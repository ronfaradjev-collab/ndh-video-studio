from dataclasses import dataclass
from pathlib import Path

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
VIDEO_EXTENSIONS = {".mp4", ".mov", ".m4v", ".mkv", ".webm"}
MEDIA_EXTENSIONS = IMAGE_EXTENSIONS | VIDEO_EXTENSIONS


@dataclass(frozen=True)
class VideoConfig:
    language: str = "he"
    gender: str = "female"
    style: str = "luxury"
    duration: int = 60
    captions: bool = True
    music: bool = True
    width: int = 1920
    height: int = 1080
    fps: int = 25
    intro_seconds: float = 3.5
    outro_seconds: float = 4.5
    speech_gap: float = 0.5
    voice_provider: str = "edge"

    def validate(self) -> None:
        if self.language != "he" or self.gender != "female" or self.style != "luxury":
            raise ValueError("MVP 0.1 supports Hebrew / female / luxury only.")
        if not 12 <= self.duration <= 180:
            raise ValueError("Duration must be between 12 and 180 seconds.")
        if self.width % 2 or self.height % 2 or min(self.width, self.height) < 144:
            raise ValueError("Even output dimensions of at least 144 pixels are required.")
        if not 15 <= self.fps <= 60:
            raise ValueError("Unsupported frame rate.")
        if self.intro_seconds + self.outro_seconds + self.speech_gap + 1 >= self.duration:
            raise ValueError("Too little space for the narration.")
        if self.voice_provider not in {"edge", "azure", "file"}:
            raise ValueError("Unsupported voice provider.")

    @property
    def main_seconds(self) -> float:
        return self.duration - self.intro_seconds - self.outro_seconds

    @property
    def voice_start(self) -> float:
        return self.intro_seconds + self.speech_gap

    @property
    def voice_max_seconds(self) -> float:
        return self.duration - self.outro_seconds - self.voice_start - 0.5


@dataclass
class Branding:
    property_title: str = "בית יוצא דופן בנתניה"
    presenter: str = "מרינה | Home in Israel"
    website: str = "netanyadreamhome.com"
    phone: str = "+972 54-649-8202"
    logo: Path | None = None
    portrait: Path | None = None
    soundtrack: Path | None = None
