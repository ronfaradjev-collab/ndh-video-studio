import json
import shutil
import subprocess
from pathlib import Path


class VideoStudioError(RuntimeError):
    pass


def check_dependencies() -> None:
    for name in ("ffmpeg", "ffprobe"):
        if not shutil.which(name):
            raise VideoStudioError(f"{name} missing from PATH. Install FFmpeg (including ffprobe).")
    p = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], text=True, capture_output=True)
    if p.returncode != 0 or " ass " not in p.stdout:
        raise VideoStudioError("FFmpeg must be compiled with libass for Hebrew burned captions.")
    p = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], text=True, capture_output=True)
    if p.returncode != 0 or "libx264" not in p.stdout:
        raise VideoStudioError("FFmpeg must include the libx264 encoder.")


def run(args: list[str], cwd: Path | None = None) -> None:
    p = subprocess.run(args, cwd=cwd, text=True, capture_output=True, encoding="utf-8", errors="replace")
    if p.returncode:
        detail = "\n".join(p.stderr.splitlines()[-24:])
        raise VideoStudioError(f"Command failed ({p.returncode}): {args[0]}\n{detail}")


def probe(path: Path) -> dict:
    p = subprocess.run([
        "ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", str(path)
    ], text=True, capture_output=True, encoding="utf-8", errors="replace")
    if p.returncode:
        raise VideoStudioError(f"Cannot read media: {path.name}: {p.stderr[-350:]}")
    try:
        return json.loads(p.stdout)
    except ValueError as exc:
        raise VideoStudioError("Invalid ffprobe response") from exc


def duration(path: Path) -> float:
    info = probe(path)
    secs = float(info.get("format", {}).get("duration") or 0)
    if secs <= 0:
        raise VideoStudioError(f"Audio/video has invalid duration: {path.name}")
    return secs
