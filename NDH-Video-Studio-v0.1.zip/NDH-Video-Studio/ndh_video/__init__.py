"""NDH Video Studio — local, template-driven real estate video production."""
__version__ = "0.1.0"
