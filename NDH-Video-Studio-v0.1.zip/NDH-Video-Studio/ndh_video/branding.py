"""Luxury editorial 16:9 opening/closing frames, with optional authentic branding assets."""
import os
from pathlib import Path

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps, features

from .config import Branding, VideoConfig
from .utils import VideoStudioError

NAVY = (11, 24, 39)
IVORY = (246, 240, 228)
GOLD = (191, 162, 113)


def _font_path(serif: bool = False) -> str:
    override = os.getenv("NDH_FONT_SERIF" if serif else "NDH_FONT_SANS")
    if override and Path(override).is_file():
        return override
    if os.name == "nt":
        paths = [r"C:\Windows\Fonts\times.ttf", r"C:\Windows\Fonts\arial.ttf"] if serif else [r"C:\Windows\Fonts\arial.ttf"]
    else:
        paths = ([
            "/usr/share/fonts/truetype/noto/NotoSerifHebrew-Regular.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
        ] if serif else [
            "/usr/share/fonts/truetype/noto/NotoSansHebrew-Regular.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        ])
    return next((p for p in paths if Path(p).is_file()), paths[-1])


def _font(size: int, serif: bool = False) -> ImageFont.FreeTypeFont:
    try:
        return ImageFont.truetype(_font_path(serif), size=size)
    except OSError as exc:
        raise VideoStudioError("No Hebrew font found. Install Noto Sans Hebrew or set NDH_FONT_SANS.") from exc


def _latin_font(size: int) -> ImageFont.FreeTypeFont:
    if os.name == "nt":
        paths = [r"C:\Windows\Fonts\arial.ttf"]
    else:
        paths = ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                 "/Library/Fonts/Arial.ttf",
                 "/System/Library/Fonts/Supplemental/Arial.ttf"]
    path = next((p for p in paths if Path(p).is_file()), _font_path(False))
    return ImageFont.truetype(path, size=size)


def _rtl(draw: ImageDraw.ImageDraw, xy: tuple[int, int], txt: str, fill, font, anchor: str = "ra") -> None:
    kwargs = {"font": font, "fill": fill, "anchor": anchor}
    if features.check("raqm"):
        kwargs["direction"] = "rtl"
    draw.text(xy, txt, **kwargs)


def _background(first_media: Path, width: int, height: int) -> Image.Image:
    if first_media.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
        try:
            background = Image.open(first_media).convert("RGB")
            background = ImageOps.fit(background, (width, height), method=Image.Resampling.LANCZOS)
        except Exception:
            background = Image.new("RGB", (width, height), NAVY)
    else:
        background = Image.new("RGB", (width, height), NAVY)
    background = ImageEnhance.Contrast(background).enhance(1.07)
    dark = Image.new("RGBA", (width, height), NAVY + (0,))
    d = ImageDraw.Draw(dark)
    for x in range(width):
        alpha = round(235 - 40 * x / max(1, width))
        d.line([(x, 0), (x, height)], fill=NAVY + (alpha,))
    return Image.alpha_composite(background.convert("RGBA"), dark)


def _logo_or_label(canvas: Image.Image, branding: Branding, x: int, y: int, size: int) -> None:
    d = ImageDraw.Draw(canvas)
    if branding.logo and branding.logo.exists():
        logo = Image.open(branding.logo).convert("RGBA")
        logo.thumbnail((round(size * 3.5), round(size * 1.5)), Image.Resampling.LANCZOS)
        canvas.alpha_composite(logo, (x, y))
    else:
        d.text((x, y), "HOME IN ISRAEL", font=_latin_font(size), fill=IVORY)


def _portrait(canvas: Image.Image, image_path: Path | None, cx: int, cy: int, radius: int) -> None:
    if not image_path or not image_path.exists():
        draw = ImageDraw.Draw(canvas)
        draw.ellipse((cx-radius, cy-radius, cx+radius, cy+radius), outline=GOLD, width=max(2, radius//25))
        draw.text((cx, cy), "M", anchor="mm", font=_latin_font(int(radius*.95)), fill=GOLD)
        return
    photo = Image.open(image_path).convert("RGB")
    side = radius * 2
    photo = ImageOps.fit(photo, (side, side), centering=(0.5, 0.35))
    mask = Image.new("L", (side, side), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, side - 1, side - 1), fill=255)
    canvas.paste(photo, (cx - radius, cy - radius), mask)
    d = ImageDraw.Draw(canvas)
    d.ellipse((cx - radius - 4, cy - radius - 4, cx + radius + 4, cy + radius + 4), outline=GOLD, width=max(2, radius // 30))


def create_frames(branding: Branding, cfg: VideoConfig, first_media: Path, out_dir: Path) -> tuple[Path, Path]:
    w, h = cfg.width, cfg.height
    scale = h / 1080
    def sc(n: int) -> int:
        return max(1, round(n * scale))

    intro = _background(first_media, w, h)
    d = ImageDraw.Draw(intro)
    _logo_or_label(intro, branding, sc(115), sc(92), sc(24))
    d.line((sc(115), sc(228), sc(380), sc(228)), fill=GOLD, width=sc(3))
    _rtl(d, (w - sc(115), sc(445)), branding.property_title[:65], IVORY, _font(sc(73), serif=True))
    _rtl(d, (w - sc(115), sc(540)), "סיור בנכס | נתניה", GOLD, _font(sc(34)))
    d.text((sc(115), h - sc(105)), "NETANYA DREAM HOME  /  PROPERTY FILM", fill=IVORY, font=_latin_font(sc(22)))
    intro_path = out_dir / "intro.png"
    intro.convert("RGB").save(intro_path, optimize=True)

    outro = Image.new("RGBA", (w, h), NAVY + (255,))
    d = ImageDraw.Draw(outro)
    d.line((sc(110), sc(180), w - sc(110), sc(180)), fill=GOLD, width=sc(2))
    _portrait(outro, branding.portrait, sc(285), sc(530), sc(155))
    _rtl(d, (w - sc(130), sc(370)), "הבית הבא שלכם מתחיל כאן", IVORY, _font(sc(67), serif=True))
    _rtl(d, (w - sc(130), sc(465)), "מרינה | יועצת נדל״ן מבית הום אין ישראל", GOLD, _font(sc(32)))
    d.text((w - sc(130), sc(580)), branding.phone, fill=IVORY, font=_latin_font(sc(31)), anchor="ra")
    d.text((w - sc(130), sc(640)), branding.website, fill=IVORY, font=_latin_font(sc(29)), anchor="ra")
    _logo_or_label(outro, branding, sc(110), h - sc(127), sc(22))
    d.line((sc(110), h - sc(158), w - sc(110), h - sc(158)), fill=GOLD, width=sc(2))
    outro_path = out_dir / "outro.png"
    outro.convert("RGB").save(outro_path, optimize=True)
    return intro_path, outro_path
