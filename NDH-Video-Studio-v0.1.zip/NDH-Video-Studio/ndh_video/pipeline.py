"""The render pipeline keeps each production in its own reproducible job directory."""
import json
import shutil
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Callable

from PIL import Image, ImageOps

from .branding import create_frames
from .captions import make_cues, write_subtitles
from .config import Branding, IMAGE_EXTENSIONS, VIDEO_EXTENSIONS, VideoConfig
from .music import generate_music
from .render import mux_master, render_video
from .tts import create_narration
from .utils import VideoStudioError, check_dependencies, duration, probe, run


def _normalize_media(inputs: list[Path], job: Path) -> list[Path]:
    normalized: list[Path] = []
    directory = job / "normalized"
    directory.mkdir(exist_ok=True)
    for i, file in enumerate(inputs):
        if not file.is_file():
            raise VideoStudioError(f"Missing file: {file}")
        ext = file.suffix.lower()
        if ext in IMAGE_EXTENSIONS:
            try:
                with Image.open(file) as original:
                    image = ImageOps.exif_transpose(original).convert("RGB")
                    image.thumbnail((3840, 3840), Image.Resampling.LANCZOS)
                    path = directory / f"asset_{i:03}.jpg"
                    image.save(path, quality=93, subsampling=0)
            except Exception as exc:
                raise VideoStudioError(f"Unreadable image: {file.name}") from exc
        elif ext in VIDEO_EXTENSIONS:
            streams = probe(file).get("streams", [])
            if not any(stream.get("codec_type") == "video" for stream in streams):
                raise VideoStudioError(f"Not a video: {file.name}")
            path = file
        else:
            raise VideoStudioError(f"Unsupported media file: {file.name}")
        normalized.append(path)
    return normalized


def _poster_from_video(video: Path, out: Path) -> Path:
    run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(video),
         "-frames:v", "1", str(out)])
    return out


def produce(
    media: list[Path], script: str, branding: Branding, cfg: VideoConfig,
    job: Path, voice_file: Path | None = None,
    progress: Callable[[str, float], None] | None = None,
) -> dict:
    def notify(message: str, fraction: float) -> None:
        if progress:
            progress(message, fraction)

    cfg.validate()
    check_dependencies()
    if not media or len(media) > 120:
        raise VideoStudioError("Upload between 1 and 120 media files.")
    if not script.strip():
        raise VideoStudioError("Enter a narration script.")
    if len(script) > 5500:
        raise VideoStudioError("Script is too long for a short property film.")
    job = job.resolve()
    job.mkdir(parents=True, exist_ok=True)
    notify("Preparing uploaded media", .04)
    normalized = _normalize_media(media, job)

    notify("Synthesizing female Hebrew voice", .14)
    narration = job / "narration.mp3"
    if cfg.voice_provider == "file":
        if not voice_file or not voice_file.exists():
            raise VideoStudioError("Select and upload an MP3 or WAV narration file.")
        narration = job / f"narration{voice_file.suffix.lower()}"
        shutil.copyfile(voice_file, narration)
    words = create_narration(script, narration, cfg.voice_provider)
    voice_seconds = duration(narration)
    if voice_seconds > cfg.voice_max_seconds:
        raise VideoStudioError(
            f"Voice lasts {voice_seconds:.1f}s but the available slot is {cfg.voice_max_seconds:.1f}s. "
            "Shorten the script or choose a longer video duration."
        )

    notify("Synchronizing subtitles", .28)
    cues, word_timing = make_cues(words, script, voice_seconds, cfg.voice_start)
    write_subtitles(cues, job, cfg.height)

    background = normalized[0]
    if background.suffix.lower() in VIDEO_EXTENSIONS:
        background = _poster_from_video(background, job / "first_video_frame.png")
    notify("Rendering branded intro and outro", .36)
    intro, outro = create_frames(branding, cfg, background, job)

    notify("Building cinematic timeline", .45)
    silent = render_video(normalized, intro, outro, cfg, job)

    notify("Mixing background soundtrack", .78)
    music = None
    if cfg.music:
        if branding.soundtrack and branding.soundtrack.is_file():
            music = branding.soundtrack
        else:
            music = job / "ambient_original.wav"
            generate_music(music, cfg.duration)

    notify("Mastering sound, subtitles and MP4", .86)
    master = mux_master(silent, narration, music, cfg, job)
    report = {
        "status": "success", "created": datetime.now().isoformat(timespec="seconds"),
        "config": asdict(cfg), "title": branding.property_title,
        "source_count": len(media), "voice_duration_seconds": round(voice_seconds, 2),
        "caption_timing": "word_boundaries" if word_timing else "estimated_from_script",
        "final_video": master.name, "srt": "captions.srt",
        "music": "user_provided" if branding.soundtrack else "generated_original" if cfg.music else "off",
        "notes": [
            "The MVP uses the order of uploaded assets; there is no AI scene understanding yet.",
            "Voice file mode uses estimated subtitle timing; upload accurate speech timestamps in a future version.",
            "Branding fields, visuals and property facts require human approval before publication."
        ],
    }
    (job / "job_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    notify("Finished", 1.0)
    return {"video": master, "subtitles": job / "captions.srt", "report": job / "job_report.json", "details": report}
