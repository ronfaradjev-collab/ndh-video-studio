"""Deterministic FFmpeg rendering. No shell strings or untrusted filename interpolation."""
import math
from pathlib import Path

from .config import VideoConfig, VIDEO_EXTENSIONS
from .utils import run, VideoStudioError


def segment_plan(files: list[Path], seconds: float) -> list[tuple[Path, float]]:
    if not files:
        raise VideoStudioError("Upload at least one image or video.")
    # Average six seconds per cut. Repeat sparse photo sets instead of holding static for 40s.
    count = max(len(files), math.ceil(seconds / 6.5))
    if count > 120:
        raise VideoStudioError("Too many media files (max 120).")
    frame_seconds = seconds / count
    return [(files[i % len(files)], frame_seconds) for i in range(count)]


def clip(path: Path, target: Path, duration: float, cfg: VideoConfig, kind: str) -> None:
    w, h, fps = cfg.width, cfg.height, cfg.fps
    frame_count = max(1, round(duration * fps))
    is_video = kind == "media" and path.suffix.lower() in VIDEO_EXTENSIONS
    if is_video:
        inp = ["-stream_loop", "-1", "-i", str(path)]
        filt = (
            f"fps={fps},scale={w}:{h}:force_original_aspect_ratio=increase,"
            f"crop={w}:{h},setsar=1,format=yuv420p"
        )
    else:
        inp = ["-loop", "1", "-framerate", str(fps), "-i", str(path)]
        if kind == "media":
            # Moving still photographs: a subtle progressive camera push, centered.
            big_w, big_h = math.ceil(w * 1.12 / 2) * 2, math.ceil(h * 1.12 / 2) * 2
            filt = (
                f"scale={big_w}:{big_h}:force_original_aspect_ratio=increase,"
                f"crop={big_w}:{big_h},"
                f"zoompan=z='min(zoom+0.00045,1.10)':"
                f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s={w}x{h}:fps={fps},"
                "setsar=1,format=yuv420p"
            )
        else:
            filt = f"scale={w}:{h},setsar=1,format=yuv420p"
    run([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *inp,
        "-vf", filt, "-frames:v", str(frame_count), "-an", "-c:v", "libx264",
        "-preset", "veryfast", "-crf", "20", "-r", str(fps), "-pix_fmt", "yuv420p",
        "-video_track_timescale", "90000", str(target)
    ])


def render_video(files: list[Path], intro: Path, outro: Path, cfg: VideoConfig, job: Path) -> Path:
    parts_dir = job / "parts"
    parts_dir.mkdir(parents=True, exist_ok=True)
    plan = [(intro, cfg.intro_seconds, "title")]
    plan += [(file, secs, "media") for file, secs in segment_plan(files, cfg.main_seconds)]
    plan.append((outro, cfg.outro_seconds, "title"))
    # Use exact integer frame allocation to avoid accumulating rounding errors.
    total_frames = cfg.duration * cfg.fps
    first_frames = round(cfg.intro_seconds * cfg.fps)
    last_frames = round(cfg.outro_seconds * cfg.fps)
    remaining = total_frames - first_frames - last_frames
    main_count = len(plan) - 2
    base, extra = divmod(remaining, main_count)
    lengths = [first_frames] + [base + (i < extra) for i in range(main_count)] + [last_frames]
    outpaths = []
    for i, ((file, _, kind), frames) in enumerate(zip(plan, lengths)):
        output = parts_dir / f"scene_{i:03d}.mp4"
        clip(file, output, frames / cfg.fps, cfg, kind)
        outpaths.append(output)
    manifest = job / "concat.txt"
    # FFmpeg's concat list includes only app-generated scene paths (no user filename).
    manifest.write_text("".join(f"file 'parts/{p.name}'\n" for p in outpaths), encoding="utf-8")
    silent = job / "silent.mp4"
    run([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-f", "concat", "-safe", "0", "-i", str(manifest),
        "-c:v", "copy", "-an", str(silent)
    ], cwd=job)
    return silent


def mux_master(silent: Path, narration: Path, music: Path | None, cfg: VideoConfig, job: Path) -> Path:
    args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(silent), "-i", str(narration)]
    if music:
        args += ["-stream_loop", "-1", "-i", str(music)]
    # Audio begins after intro. Preserve intro/outro ambience, duck music during narration.
    common = f"adelay={round(cfg.voice_start * 1000)}:all=1,aresample=48000,volume=1.1,apad=whole_dur={cfg.duration}"
    if music:
        mix = (
            f"[1:a]{common},asplit=2[side][speech];"
            f"[2:a]atrim=duration={cfg.duration},asetpts=PTS-STARTPTS,aresample=48000,"
            f"volume=0.55,afade=t=in:st=0:d=1,afade=t=out:st={cfg.duration-2}:d=2[bg];"
            f"[bg][side]sidechaincompress=threshold=0.035:ratio=8:attack=50:release=450[ducked];"
            f"[speech][ducked]amix=inputs=2:duration=first:normalize=0,"
            f"alimiter=limit=0.94,atrim=duration={cfg.duration}[mix]"
        )
    else:
        mix = f"[1:a]{common},alimiter=limit=0.94,atrim=duration={cfg.duration}[mix]"
    args += ["-filter_complex", mix]
    if cfg.captions:
        # Run in job directory so filter path has no platform-specific colons or quoting.
        args += ["-vf", "ass=filename=captions.ass"]
    result = job / "NDH_YouTube_1080p.mp4" if (cfg.width, cfg.height) == (1920, 1080) else job / "NDH_preview.mp4"
    args += [
        "-map", "0:v:0", "-map", "[mix]", "-c:v", "libx264", "-preset", "fast",
        "-crf", "19", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
        "-ar", "48000", "-t", str(cfg.duration), "-movflags", "+faststart", str(result)
    ]
    run(args, cwd=job)
    return result
