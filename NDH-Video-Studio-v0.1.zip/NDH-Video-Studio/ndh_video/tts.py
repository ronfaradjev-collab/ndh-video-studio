"""Word-level timing when available. Edge mode needs internet and is not an official SLA."""
import json
import os
from dataclasses import dataclass
from pathlib import Path

from .utils import VideoStudioError


VOICE_HE_FEMALE = "he-IL-HilaNeural"


@dataclass
class Word:
    start: float
    end: float
    text: str


def edge_synthesize(script: str, audio: Path) -> list[Word]:
    try:
        import edge_tts
    except ImportError as exc:
        raise VideoStudioError("Install requirements.txt (edge-tts is missing).") from exc
    meta = audio.with_suffix(".jsonl")
    try:
        edge_tts.Communicate(script, VOICE_HE_FEMALE, rate="-3%", boundary="WordBoundary").save_sync(
            str(audio), str(meta)
        )
    except Exception as exc:
        raise VideoStudioError(
            "Edge speech service failed. Check internet, retry, or select Azure F0 / upload a voice track. "
            f"Underlying error: {exc}"
        ) from exc
    words: list[Word] = []
    if meta.exists():
        for line in meta.read_text(encoding="utf-8").splitlines():
            try:
                x = json.loads(line)
                if x.get("type") == "WordBoundary":
                    start = float(x["offset"]) / 10_000_000
                    span = float(x["duration"]) / 10_000_000
                    words.append(Word(start, start + max(span, 0.06), str(x["text"])))
            except (KeyError, TypeError, ValueError):
                continue
    if not audio.exists() or audio.stat().st_size < 1000:
        raise VideoStudioError("TTS returned empty audio.")
    return words


def azure_synthesize(script: str, audio: Path) -> list[Word]:
    try:
        import azure.cognitiveservices.speech as speechsdk
    except ImportError as exc:
        raise VideoStudioError("Run: pip install -r requirements-azure.txt") from exc
    key, region = os.getenv("AZURE_SPEECH_KEY"), os.getenv("AZURE_SPEECH_REGION")
    if not key or not region:
        raise VideoStudioError("Set AZURE_SPEECH_KEY and AZURE_SPEECH_REGION in .env")
    speech_cfg = speechsdk.SpeechConfig(subscription=key, region=region)
    speech_cfg.speech_synthesis_voice_name = VOICE_HE_FEMALE
    speech_cfg.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Audio24Khz48KBitRateMonoMp3)
    audio_cfg = speechsdk.audio.AudioOutputConfig(filename=str(audio))
    synth = speechsdk.SpeechSynthesizer(speech_config=speech_cfg, audio_config=audio_cfg)
    words: list[Word] = []

    def on_word(event) -> None:
        # SDK offsets are 100-nanosecond ticks.
        start = event.audio_offset / 10_000_000
        span = event.duration.total_seconds() if hasattr(event.duration, "total_seconds") else float(event.duration) / 10_000_000
        if event.text.strip():
            words.append(Word(start, start + max(0.07, span), event.text.strip()))

    synth.synthesis_word_boundary.connect(on_word)
    result = synth.speak_text_async(script).get()
    if result.reason != speechsdk.ResultReason.SynthesizingAudioCompleted:
        details = getattr(result, "cancellation_details", None)
        raise VideoStudioError(f"Azure TTS failed: {details}")
    return sorted(words, key=lambda w: w.start)


def create_narration(script: str, audio: Path, provider: str) -> list[Word]:
    if provider == "edge":
        return edge_synthesize(script, audio)
    if provider == "azure":
        return azure_synthesize(script, audio)
    if provider == "file":
        if not audio.exists():
            raise VideoStudioError("Upload a pre-recorded narration file.")
        return []
    raise VideoStudioError(f"Unknown TTS provider: {provider}")
