"""Original generated understated ambient bed, no external downloads or music licenses."""
from pathlib import Path
import wave

import numpy as np


def generate_music(destination: Path, duration: float) -> None:
    sr = 24000
    n = int(sr * duration)
    t = np.arange(n, dtype=np.float64) / sr
    bed = np.zeros(n, dtype=np.float64)
    # Gentle A-minor / F / C / G: sustained chords with a slow rolling arpeggio.
    chords = [(220, 261.63, 329.63), (174.61, 220, 261.63),
              (261.63, 329.63, 392), (196, 246.94, 293.66)]
    chord_seconds = 8.0
    for k in range(int(np.ceil(duration / chord_seconds))):
        left, right = int(sr * k * chord_seconds), min(n, int(sr * (k + 1) * chord_seconds))
        if left >= right:
            break
        tc = t[left:right] - k * chord_seconds
        window = np.minimum(1.0, tc / 1.4) * np.minimum(1.0, (right - left) / sr / 1.2 - tc / 1.2)
        window = np.clip(window, 0, 1)
        freqs = chords[k % len(chords)]
        pad = sum(np.sin(2 * np.pi * f * tc) + .20 * np.sin(2 * np.pi * (f * .5) * tc)
                  for f in freqs) / 3.6
        bed[left:right] += pad * window * 0.11
        for beat in np.arange(0, chord_seconds, 2.0):
            begin = left + int(beat * sr)
            end = min(right, begin + int(sr * 1.6))
            if begin >= end:
                continue
            tb = np.arange(end - begin) / sr
            tone = freqs[int(beat / 2) % 3] * 2
            pluck = np.exp(-tb * 2.9) * (np.sin(2 * np.pi * tone * tb) + .22 * np.sin(4 * np.pi * tone * tb))
            bed[begin:end] += .038 * pluck
    overall_fade = np.clip(t / 1.7, 0, 1) * np.clip((duration - t) / 2, 0, 1)
    samples = np.int16(np.clip(bed * overall_fade, -0.99, 0.99) * 32767)
    with wave.open(str(destination), "wb") as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(sr)
        audio.writeframes(samples.tobytes())
